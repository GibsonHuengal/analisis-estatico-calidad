import { GestorTareas } from './tareas';

describe('GestorTareas', () => {
  let gestor: GestorTareas;

  beforeEach(() => {
    gestor = new GestorTareas();
  });

  it('crea una tarea pendiente con id incremental', () => {
    const a = gestor.crear('  Escribir informe ');
    const b = gestor.crear('Revisar codigo');
    expect(a).toEqual({ id: 1, titulo: 'Escribir informe', estado: 'pendiente' });
    expect(b.id).toBe(2);
  });

  it('rechaza titulos vacios', () => {
    expect(() => gestor.crear('   ')).toThrow('vacio');
  });

  it('permite el flujo pendiente -> en_progreso -> completada', () => {
    const t = gestor.crear('Tarea');
    gestor.cambiarEstado(t.id, 'en_progreso');
    expect(gestor.cambiarEstado(t.id, 'completada').estado).toBe('completada');
  });

  it('rechaza transiciones invalidas', () => {
    const t = gestor.crear('Tarea');
    expect(() => gestor.cambiarEstado(t.id, 'completada')).toThrow('Transicion no permitida');
  });

  it('lista con y sin filtro', () => {
    const t = gestor.crear('Uno');
    gestor.crear('Dos');
    gestor.cambiarEstado(t.id, 'en_progreso');
    expect(gestor.listar()).toHaveLength(2);
    expect(gestor.listar('en_progreso')).toHaveLength(1);
  });

  it('elimina y falla si no existe', () => {
    const t = gestor.crear('Uno');
    gestor.eliminar(t.id);
    expect(gestor.listar()).toHaveLength(0);
    expect(() => gestor.obtener(t.id)).toThrow('no encontrada');
  });
});

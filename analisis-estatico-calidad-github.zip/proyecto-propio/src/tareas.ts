export type Estado = 'pendiente' | 'en_progreso' | 'completada';

export interface Tarea {
  id: number;
  titulo: string;
  estado: Estado;
}

const TRANSICIONES: Record<Estado, Estado[]> = {
  pendiente: ['en_progreso'],
  en_progreso: ['pendiente', 'completada'],
  completada: [],
};

export class GestorTareas {
  private tareas: Tarea[] = [];
  private siguienteId = 1;

  crear(titulo: string): Tarea {
    const limpio = titulo.trim();
    if (limpio.length === 0) {
      throw new Error('El titulo no puede estar vacio');
    }
    const tarea: Tarea = { id: this.siguienteId++, titulo: limpio, estado: 'pendiente' };
    this.tareas.push(tarea);
    return tarea;
  }

  obtener(id: number): Tarea {
    const tarea = this.tareas.find((t) => t.id === id);
    if (!tarea) {
      throw new Error(`Tarea ${id} no encontrada`);
    }
    return tarea;
  }

  cambiarEstado(id: number, nuevo: Estado): Tarea {
    const tarea = this.obtener(id);
    if (!TRANSICIONES[tarea.estado].includes(nuevo)) {
      throw new Error(`Transicion no permitida: ${tarea.estado} -> ${nuevo}`);
    }
    tarea.estado = nuevo;
    return tarea;
  }

  listar(estado?: Estado): Tarea[] {
    return estado ? this.tareas.filter((t) => t.estado === estado) : [...this.tareas];
  }

  eliminar(id: number): void {
    this.obtener(id);
    this.tareas = this.tareas.filter((t) => t.id !== id);
  }
}

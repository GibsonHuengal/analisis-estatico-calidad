# Análisis estático de calidad de software

Taller de gestión del cambio (Semana 11) – Evolución y Configuración de Software.

Evalúa de forma automática la **mantenibilidad, seguridad y calidad** de dos proyectos:

| Proyecto | Origen |
|---|---|
| `nestjs-espacios` | Descargado de GitHub: <https://github.com/ualmtorres/nestjs-espacios/releases/tag/v0.0.1> |
| `proyecto-propio` | Carpeta `proyecto-propio/` (ejemplo; reemplazable por el proyecto real) |

📄 **Informe con resultados:** [`informe/INFORME.md`](informe/INFORME.md)

## Cómo ver que funciona (profesor)

### Opción A – Sin instalar nada: GitHub Actions
1. Entrar a la pestaña **Actions** de este repositorio.
2. Abrir el workflow **Análisis estático** → **Run workflow** (o simplemente hacer un push).
3. Al terminar, abrir cada job: el **resumen** muestra la puerta de calidad aprobada/no aprobada, y en *Artifacts* se descargan los reportes.

### Opción B – En local (Node.js 18+ y Git)
```bash
git clone <URL-de-este-repositorio> && cd analisis-estatico-calidad

# 1) proyecto propio
./scripts/analizar-local.sh proyecto-propio

# 2) proyecto descargado de GitHub
git clone --depth 1 --branch v0.0.1 https://github.com/ualmtorres/nestjs-espacios.git objetivo/nestjs-espacios
./scripts/analizar-local.sh objetivo/nestjs-espacios nestjs-espacios
```
En Windows usar **Git Bash** o WSL. Los resultados quedan en `reports/<proyecto>/resumen.md`.

### Opción C – Con SonarQube real (Docker), como en la clase
```bash
docker compose up -d                          # SonarQube en http://localhost:9000 (admin / admin)
# Crear token: Mi cuenta > Seguridad > Generar tokens
SONAR_TOKEN=squ_xxxxx scripts/sonarqube-local.sh
```
El script clona `nestjs-espacios`, genera cobertura y ejecuta `sonar-scanner` (imagen oficial `sonarsource/sonar-scanner-cli`) con el archivo [`sonar-project.properties`](sonar-project.properties). El dashboard queda en <http://localhost:9000/dashboard?id=nestjs-espacios>.

> Estado de verificación: las opciones A (script) y B fueron ejecutadas y los resultados están en `reports/`. La opción C y el job opcional de SonarQube en el workflow **no pudieron probarse** al preparar el repositorio (sin Docker/SonarQube disponibles), por lo que podrían requerir algún ajuste.

## Qué mide cada herramienta

| Dimensión | Herramienta | Equivalente en SonarQube |
|---|---|---|
| Mantenibilidad | `eslint-plugin-sonarjs`, `jscpd` | Code smells, duplicación, complejidad |
| Seguridad | `eslint-plugin-security`, `npm audit` | Vulnerabilidades, security hotspots |
| Calidad / fiabilidad | `tsc`, Jest + cobertura | Bugs, cobertura |

La **puerta de calidad** (ver `scripts/resumen.js`): compila, pruebas pasan, cobertura ≥ 80 %, duplicación ≤ 3 %, sin vulnerabilidades críticas/altas, sin hallazgos de seguridad ni code smells.

## Estructura
```
.github/workflows/analisis-estatico.yml  CI: ejecuta el análisis en ambos proyectos
docker-compose.yml                       SonarQube Community + PostgreSQL
sonar-project.properties                 Configuración del scanner (nestjs-espacios)
scripts/                                 analizar-local.sh, sonarqube-local.sh, resumen.js
herramientas/                            Dependencias y reglas de análisis
proyecto-propio/                         Proyecto de ejemplo con pruebas
reports/                                 Resultados ya generados
informe/INFORME.md                       Informe del taller
```

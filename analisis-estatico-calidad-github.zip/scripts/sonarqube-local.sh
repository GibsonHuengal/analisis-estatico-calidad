#!/usr/bin/env bash
# Analisis con SonarQube real (como en la clase de la Semana 11).
# Requisitos: Docker. Pasos que automatiza:
#   1) levanta SonarQube en http://localhost:9000
#   2) clona el proyecto de GitHub y genera cobertura
#   3) ejecuta sonar-scanner (en contenedor) contra el servidor
#
# Uso: SONAR_TOKEN=<token> scripts/sonarqube-local.sh [carpeta-proyecto]
# Si no hay token, entra a http://localhost:9000 (admin/admin), cambia la clave,
# y crea uno en: Mi cuenta > Seguridad > Generar tokens.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TARGET="${1:-$ROOT/objetivo/nestjs-espacios}"

if [ ! -d "$TARGET" ]; then
  mkdir -p "$ROOT/objetivo"
  git clone --depth 1 --branch v0.0.1 https://github.com/ualmtorres/nestjs-espacios.git "$TARGET"
fi

echo ">> Levantando SonarQube..."
docker compose -f "$ROOT/docker-compose.yml" up -d
printf ">> Esperando a que SonarQube este operativo"
until curl -s http://localhost:9000/api/system/status | grep -q '"status":"UP"'; do printf "."; sleep 5; done
echo " listo"

if [ -z "${SONAR_TOKEN:-}" ]; then
  echo "Falta SONAR_TOKEN. Crea un token en http://localhost:9000 y vuelve a ejecutar:"
  echo "  SONAR_TOKEN=squ_xxx scripts/sonarqube-local.sh"
  exit 1
fi

cd "$TARGET"
[ -d node_modules ] || npm install --no-audit --no-fund --ignore-scripts
npx jest --coverage --coverageReporters=lcov || true
cp "$ROOT/sonar-project.properties" ./sonar-project.properties

docker run --rm --network host -e SONAR_TOKEN="$SONAR_TOKEN" \
  -v "$TARGET:/usr/src" sonarsource/sonar-scanner-cli \
  -Dsonar.host.url=http://localhost:9000
echo ">> Resultados: http://localhost:9000/dashboard?id=nestjs-espacios"

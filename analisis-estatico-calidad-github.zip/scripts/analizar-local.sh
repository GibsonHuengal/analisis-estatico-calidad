#!/usr/bin/env bash
# Analisis estatico automatico de un proyecto Node/TypeScript.
# Uso: scripts/analizar-local.sh <carpeta-del-proyecto> [nombre-del-informe]
#
# Mide: mantenibilidad (code smells, complejidad, duplicacion),
#       seguridad (reglas de seguridad + npm audit) y
#       calidad/fiabilidad (compilacion TypeScript + pruebas + cobertura).
# Genera: reports/<nombre>/ con los resultados crudos y resumen.md
set -uo pipefail

DIR="${1:?Uso: $0 <carpeta-del-proyecto> [nombre]}"
NAME="${2:-$(basename "$DIR")}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/reports/$NAME"
DIR="$(cd "$DIR" && pwd)"
mkdir -p "$OUT"

echo ">> [1/6] Instalando herramientas de analisis"
(cd "$ROOT/herramientas" && npm install --no-audit --no-fund --silent) || exit 1
BIN="$ROOT/herramientas/node_modules/.bin"

cd "$DIR"
echo ">> [2/6] Instalando dependencias del proyecto ($NAME)"
if [ ! -d node_modules ]; then
  npm install --no-audit --no-fund --ignore-scripts --silent || true
fi

echo ">> [3/6] Compilacion TypeScript (fiabilidad)"
if [ -f tsconfig.json ]; then
  "$BIN/tsc" --noEmit -p tsconfig.json > "$OUT/tsc.txt" 2>&1
  echo "$?" > "$OUT/tsc.exitcode"
else
  echo "sin tsconfig.json" > "$OUT/tsc.txt"; echo 0 > "$OUT/tsc.exitcode"
fi

echo ">> [4/6] Pruebas unitarias + cobertura"
npx --no-install jest --coverage --coverageReporters=json-summary --coverageReporters=lcov \
  --coverageDirectory "$OUT/coverage" > "$OUT/jest.txt" 2>&1
echo "$?" > "$OUT/jest.exitcode"

echo ">> [5/6] Reglas SonarJS + seguridad, duplicacion y dependencias"
cp "$ROOT/herramientas/eslintrc.json" "$ROOT/herramientas/.eslintrc.analisis.json"
"$BIN/eslint" --no-eslintrc -c "$ROOT/herramientas/.eslintrc.analisis.json" \
  --resolve-plugins-relative-to "$ROOT/herramientas" \
  --ext .ts,.js "src" -f json -o "$OUT/eslint.json" > /dev/null 2>&1
rm -f "$ROOT/herramientas/.eslintrc.analisis.json"
"$BIN/jscpd" src --min-tokens 40 --reporters json --output "$OUT/jscpd" --silent > /dev/null 2>&1
npm audit --json > "$OUT/audit.json" 2>/dev/null || true
find src -name '*.ts' ! -name '*.spec.ts' | xargs cat | wc -l > "$OUT/loc.txt"

echo ">> [6/6] Generando resumen"
node "$ROOT/scripts/resumen.js" "$OUT" "$NAME" > "$OUT/resumen.md"
cat "$OUT/resumen.md"
echo
echo "Resultados en: $OUT"

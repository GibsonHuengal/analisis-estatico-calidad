#!/usr/bin/env node
// Lee los resultados crudos de reports/<nombre>/ y imprime un resumen en Markdown
// con una "puerta de calidad" equivalente a la de SonarQube (Sonar way).
const fs = require('fs');
const path = require('path');

const out = process.argv[2];
const name = process.argv[3] || path.basename(out);
const read = (f, fallback) => {
  try { return fs.readFileSync(path.join(out, f), 'utf8'); } catch { return fallback; }
};
const json = (f, fallback) => { try { return JSON.parse(read(f, '')); } catch { return fallback; } };

// --- ESLint (SonarJS + security) ---
const eslint = json('eslint.json', []);
const byRule = {};
const byFile = {};
let issues = 0;
for (const f of eslint) {
  for (const m of f.messages) {
    issues++;
    byRule[m.ruleId] = (byRule[m.ruleId] || 0) + 1;
    const rel = f.filePath.split(/[\\/]src[\\/]/).pop();
    byFile[rel] = (byFile[rel] || 0) + 1;
  }
}
const securityIssues = Object.entries(byRule)
  .filter(([r]) => r && r.startsWith('security/'))
  .reduce((a, [, n]) => a + n, 0);
const sonarIssues = Object.entries(byRule)
  .filter(([r]) => r && (r.startsWith('sonarjs/') || r.endsWith('no-unused-vars')))
  .reduce((a, [, n]) => a + n, 0);

// --- Cobertura ---
const cov = json('coverage/coverage-summary.json', null);
const covLines = cov ? cov.total.lines.pct : null;

// --- Duplicacion ---
const cpd = json('jscpd/jscpd-report.json', null);
const dupPct = cpd ? Math.round(cpd.statistics.total.percentage * 100) / 100 : null;
const dupClones = cpd ? cpd.statistics.total.clones : null;

// --- Dependencias ---
const audit = json('audit.json', null);
const v = (audit && audit.metadata && audit.metadata.vulnerabilities) || {};

// --- Compilacion y pruebas ---
const tscOk = read('tsc.exitcode', '1').trim() === '0';
const jestOk = read('jest.exitcode', '1').trim() === '0';
const jestSummary = (read('jest.txt', '').match(/Tests:\s+.*/) || ['(sin datos)'])[0];
const loc = parseInt(read('loc.txt', '0').trim(), 10) || 0;

const ok = (b) => (b ? 'APROBADO' : 'FALLA');
const fmt = (n) => (n === null || n === undefined ? 'n/d' : `${n}`);

const gate = [
  ['Compila sin errores (fiabilidad)', tscOk ? 'sin errores' : 'con errores', tscOk],
  ['Pruebas unitarias pasan', jestSummary.trim(), jestOk],
  ['Cobertura >= 80 %', `${fmt(covLines)} %`, covLines !== null && covLines >= 80],
  ['Lineas duplicadas <= 3 %', `${fmt(dupPct)} %`, dupPct !== null && dupPct <= 3],
  ['Sin vulnerabilidades criticas/altas en dependencias', `${v.critical || 0} criticas, ${v.high || 0} altas`, (v.critical || 0) + (v.high || 0) === 0],
  ['Sin problemas de seguridad en el codigo', `${securityIssues} hallazgos`, securityIssues === 0],
  ['Sin code smells (SonarJS)', `${sonarIssues} hallazgos`, sonarIssues === 0],
];
const passed = gate.every((g) => g[2]);

const lines = [];
lines.push(`# Resultado del analisis estatico: ${name}`);
lines.push('');
lines.push(`Lineas de codigo (sin tests): **${loc}**`);
lines.push('');
lines.push(`## Puerta de calidad: ${passed ? 'APROBADA' : 'NO APROBADA'}`);
lines.push('');
lines.push('| Condicion | Valor medido | Estado |');
lines.push('|---|---|---|');
for (const [c, val, pass] of gate) lines.push(`| ${c} | ${val} | ${ok(pass)} |`);
lines.push('');
lines.push('## Hallazgos del codigo por regla');
lines.push('');
if (issues === 0) lines.push('Ninguno.');
else {
  lines.push('| Regla | Cantidad |');
  lines.push('|---|---|');
  for (const [r, n] of Object.entries(byRule).sort((a, b) => b[1] - a[1])) lines.push(`| ${r} | ${n} |`);
}
lines.push('');
lines.push('## Vulnerabilidades en dependencias (npm audit)');
lines.push('');
lines.push(`Criticas: ${v.critical || 0} | Altas: ${v.high || 0} | Moderadas: ${v.moderate || 0} | Bajas: ${v.low || 0} | Total: ${v.total || 0}`);
lines.push('');
lines.push('## Duplicacion');
lines.push('');
lines.push(`${fmt(dupClones)} bloques duplicados, ${fmt(dupPct)} % de lineas duplicadas.`);
console.log(lines.join('\n'));

# Resultado del analisis estatico: nestjs-espacios

Lineas de codigo (sin tests): **760**

## Puerta de calidad: NO APROBADA

| Condicion | Valor medido | Estado |
|---|---|---|
| Compila sin errores (fiabilidad) | sin errores | APROBADO |
| Pruebas unitarias pasan | Tests:       13 passed, 13 total | APROBADO |
| Cobertura >= 80 % | 39.01 % | FALLA |
| Lineas duplicadas <= 3 % | 12.33 % | FALLA |
| Sin vulnerabilidades criticas/altas en dependencias | 13 criticas, 35 altas | FALLA |
| Sin problemas de seguridad en el codigo | 0 hallazgos | APROBADO |
| Sin code smells (SonarJS) | 13 hallazgos | FALLA |

## Hallazgos del codigo por regla

| Regla | Cantidad |
|---|---|
| @typescript-eslint/no-unused-vars | 7 |
| sonarjs/no-duplicate-string | 6 |

## Vulnerabilidades en dependencias (npm audit)

Criticas: 13 | Altas: 35 | Moderadas: 20 | Bajas: 19 | Total: 87

## Duplicacion

7 bloques duplicados, 12.33 % de lineas duplicadas.

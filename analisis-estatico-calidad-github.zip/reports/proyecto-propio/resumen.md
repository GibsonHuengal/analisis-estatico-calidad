# Resultado del analisis estatico: proyecto-propio

Lineas de codigo (sin tests): **54**

## Puerta de calidad: APROBADA

| Condicion | Valor medido | Estado |
|---|---|---|
| Compila sin errores (fiabilidad) | sin errores | APROBADO |
| Pruebas unitarias pasan | Tests:       6 passed, 6 total | APROBADO |
| Cobertura >= 80 % | 100 % | APROBADO |
| Lineas duplicadas <= 3 % | 0 % | APROBADO |
| Sin vulnerabilidades criticas/altas en dependencias | 0 criticas, 0 altas | APROBADO |
| Sin problemas de seguridad en el codigo | 0 hallazgos | APROBADO |
| Sin code smells (SonarJS) | 0 hallazgos | APROBADO |

## Hallazgos del codigo por regla

Ninguno.

## Vulnerabilidades en dependencias (npm audit)

Criticas: 0 | Altas: 0 | Moderadas: 0 | Bajas: 7 | Total: 7

## Duplicacion

0 bloques duplicados, 0 % de lineas duplicadas.
